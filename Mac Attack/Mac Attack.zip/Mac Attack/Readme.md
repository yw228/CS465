To run the code 
1. Go the MACAttack.py 
Press the `play button` in the `MacAttack_main.py`
if __name__ == "__main__":
    main()
If you are using Pycharm or other IDE

2. You can also in the Mac Attack folder run the following code in the terminal

 `python3 MacAttack_main.py`
