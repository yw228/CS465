To run the code there are two ways 
Method 1. Open up the Project_4_Diffie_Hellman.ipynb in an ide or google colab
run each of the command
Method 2. If running lab machine or terminal 
2.1 Pip install sympy
2.2 Use python or python3 to run the project_4_diffie_hellman.py
2.3 The prime function will first generate a strong prime
2.4 Then pick number for a 
2.5 The result will change according to the p , a , b and other values.
If Method 2 is not working here is the link for my google colab
https://colab.research.google.com/drive/1yIErMImMO5fauILV8H4O06zy9OX9Vyj9?usp=sharing